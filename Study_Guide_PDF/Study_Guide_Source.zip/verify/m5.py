import itertools, math
P1={'a':.8,'the':.15,'dog':.05}
T={'a':{'a':.01,'the':.01,'dog':.98},'the':{'a':.15,'the':.01,'dog':.84},'dog':{'a':.3,'the':.5,'dog':.2}}
seqs={(x,y):P1[x]*T[x][y] for x in P1 for y in P1}
print(sorted(seqs.items(),key=lambda kv:-kv[1])[:4])
beam=sorted(P1,key=lambda w:-P1[w])[:2]; print('beam step1',beam)
cand=sorted([((b,y),P1[b]*T[b][y]) for b in beam for y in P1],key=lambda kv:-kv[1]); print(cand[:3])
greedy=max(P1,key=P1.get); g2=max(T[greedy],key=T[greedy].get); print('greedy',greedy,g2,P1[greedy]*T[greedy][g2])
def nucleus(d,p):
    items=sorted(d.items(),key=lambda kv:-kv[1]); out=[];c=0
    for w,q in items:
        out.append((w,q)); c+=q
        if c>=p-1e-12: break
    s=sum(q for _,q in out); return {w:q/s for w,q in out}
print(nucleus(P1,.9),{w:nucleus(T[w],.9) for w in nucleus(P1,.9)})
ex={'the':.7,'a':.1,'computer':.1,'tablet':.08,'phone':.01,'server':.01}
print(nucleus(ex,.95))
# transformer params
d,dff=512,2048
print('mhsa',4*d*d,'ffn',2*d*dff,'layer',4*d*d+2*d*dff, 'w/bias+LN', 4*d*d+4*d+2*d*dff+dff+d+4*d)
lin=lambda i,o:i*o+o
layer=3*lin(32,32)+2*64+lin(32,32)*2
print('A3 layer',layer,'total',4*layer+27*32+20*32+lin(32,27))
print('a3 ppl',math.exp(864.01857090462/500), math.exp(-math.log(1/27)))
