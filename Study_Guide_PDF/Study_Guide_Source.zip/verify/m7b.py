import math
from collections import Counter, defaultdict
from fractions import Fraction as F
def cky(words,lex,binr):
    n=len(words); C=defaultdict(dict); B={}
    for i,w in enumerate(words):
        for (X,ww),p in lex.items():
            if ww==w: C[(i,i+1)][X]=math.log2(p); B[(i,i+1,X)]=w
    for L in range(2,n+1):
        for i in range(n-L+1):
            j=i+L
            for k in range(i+1,j):
                for (X,Y,Z),p in binr.items():
                    if Y in C[(i,k)] and Z in C[(k,j)]:
                        s=math.log2(p)+C[(i,k)][Y]+C[(k,j)][Z]
                        if s>C[(i,j)].get(X,-1e9): C[(i,j)][X]=s; B[(i,j,X)]=(k,Y,Z)
    def tree(i,j,X):
        b=B[(i,j,X)]
        if isinstance(b,str): return f"({X} {b})"
        k,Y,Z=b; return f"({X} {tree(i,k,Y)} {tree(k,j,Z)})"
    return dict(C), (tree(0,n,'S') if 'S' in C[(0,n)] else None), C[(0,n)]
lex={('DT','the'):1,('NN','child'):1,('NNS','raises'):1,('VBZ','raises'):1,('PRP','it'):1}
binr={('S','NP','VP'):1,('NP','DT','NN'):.5,('NP','NN','NNS'):.5,('VP','VBZ','PRP'):1}
for s in ['the child raises it','child raises raises it','the child raises raises']:
    C,t,top=cky(s.split(),lex,binr); print(s,t,top)
    if s.startswith('the child raises it'):
        for k,v in sorted(C.items()): print('  ',k,v)
b2=dict(binr); b2[('VP','VBZ','NNS')]=1; print(cky('the child raises raises'.split(),lex,b2)[1])
l2=dict(lex); l2[('PRP','raises')]=1; print(cky('the child raises raises'.split(),l2,binr)[1])
# spaghetti grammar
lex={('PRP','I'):1,('V','ate'):1,('N','spaghetti'):.4,('N','chopsticks'):.3,('N','meatballs'):.3,('P','with'):1}
binr={('S','PRP','VP'):1,('VP','V','NP'):.6,('VP','VP','PP'):.4,('NP','NP','PP'):.2,('NP','N','N'):0}  # placeholder
# use unary NP->N folded: NP -> N not allowed in binary CKY; restructure with NP as preterminal-ish
lex={('PRP','I'):1,('V','ate'):1,('NP','spaghetti'):.8*.4,('NP','chopsticks'):.8*.3,('NP','meatballs'):.8*.3,('P','with'):1}
binr={('S','PRP','VP'):1,('VP','V','NP'):.7,('VP','VP','PP'):.3,('NP','NP','PP'):.2,('PP','P','NP'):1}
for s in ['I ate spaghetti with chopsticks','I ate spaghetti with meatballs']:
    C,t,top=cky(s.split(),lex,binr); print(s,t,top, 2**top['S'])
# both parses probability
pv=1*1*.7*.32*... if False else None
p_vp_attach=1*1*(.3)*(.7)*(.32)*1*1*.24   # S->PRP VP, VP->VP PP, VP->V NP, NP->spaghetti, PP->P NP, NP->chopsticks
p_np_attach=1*1*(.7)*(.2)*(.32)*1*1*.24
print('VP attach',p_vp_attach,'NP attach',p_np_attach)
# PCFG estimation from fa23 trees
rules=Counter({('S',('NP','VP')):2,('NP',('PRP',)):2,('NP',('NNS',)):2,('NP',('NNP',)):1,('VP',('VBP','NP','PP')):1,('VP',('VBP','NP')):1,('PP',('IN','NP')):1})
tot=Counter()
for (l,r),c in rules.items(): tot[l]+=c
for (l,r),c in rules.items(): print(l,'->',' '.join(r),F(c,tot[l]))
