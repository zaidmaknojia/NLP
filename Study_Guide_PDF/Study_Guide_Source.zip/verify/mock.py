import numpy as np, math
from fractions import Fraction as F
np.set_printoptions(precision=5, suppress=True)
sig=lambda z:1/(1+math.exp(-z))
w=np.array([1,-1,.5]); f=np.array([1,1,2.]); z=w@f; p=sig(z); print('Q3 z',z,'p',p,'w',w-0.5*p*f)
def sm(s): s=np.array(s,float); e=np.exp(s-s.max()); return e/e.sum()
print('Q5',sm([2,0,-1]))
print('Q6',300*100+100+100*50+50+50*5+5)
e=3; ex=[F(e)**1,F(1),F(1,3)]; print('Q7',[x/sum(ex) for x in ex])
print('Q11',(0.25*0.5*0.125*0.25)**(-1/4))
ex=[F(3)**1,F(3)**1,F(3)**4]; print('Q12',[x/sum(ex) for x in ex])
print('Q15',4*128**2+2*128*512)
# MC perceptron Q4
W={'pos':np.array([1,0,0.]),'neg':np.array([0,1,0.]),'neu':np.array([0,0,1.])}
x=np.array([1,1,1.]); sc={k:v@x for k,v in W.items()}; print('Q4 scores',sc)
x=np.array([2,1,0.]); sc={k:v@x for k,v in W.items()}; print('Q4b scores',sc)
# beam Q18
P1={'A':.5,'B':.3,'C':.2}
T={'A':{'A':.1,'B':.1,'C':.8},'B':{'A':.9,'B':.05,'C':.05},'C':{'A':.4,'B':.4,'C':.2}}
c=sorted([((a,b),P1[a]*T[a][b]) for a in P1 for b in P1],key=lambda kv:-kv[1]); print('all',c[:5])
beam=['A','B']; cb=sorted([((a,b),P1[a]*T[a][b]) for a in beam for b in P1],key=lambda kv:-kv[1]); print('beam2',cb[:2])
g=max(P1,key=P1.get); print('greedy',g,max(T[g],key=T[g].get))
def nuc(d,p):
    it=sorted(d.items(),key=lambda kv:-kv[1]); out=[];cum=0
    for k,v in it:
        out.append(k); cum+=v
        if cum>=p-1e-12: break
    return out
n1=nuc(P1,.75); print('nuc first',n1, {a:nuc(T[a],.75) for a in n1}, sum(len(nuc(T[a],.75)) for a in n1))
# HMM Q19
init={'D':F(1,2),'N':F(1,2)}; trans={'D':{'D':F(0),'N':F(1)},'N':{'D':F(1,4),'N':F(1,4)}}; stop={'D':F(0),'N':F(1,2)}
emit={'D':{'the':F(1)},'N':{'the':F(0),'fish':F(1,2),'swim':F(1,2)}}
print('Q19',init['D']*emit['D']['the']*trans['D']['N']*emit['N']['fish']*trans['N']['N']*emit['N']['swim']*stop['N'])
# PCFG Q21: S->NP VP 1, NP->DT N .6, NP->N .4 (unary), VP->V NP .7, VP->V .3 ; DT->the 1, N->dog .5 N->cat .5, V->sees 1
print('Q21', 1*.6*1*.5*.7*1*.4*.5)
# LONG 1 perceptron: features [good, bad, not, great], lecture rule >0
data=[([1,0,0,0],1),([0,1,0,0],-1),([1,0,1,0],-1),([0,0,0,1],1),([0,1,1,0],1)]
w=np.zeros(4)
for ep in range(3):
    for x,y in data:
        x=np.array(x,float); s=w@x; pred=1 if s>0 else -1
        if pred!=y: w=w+y*x
        print(ep+1,x,y,s,pred,w)
# LONG 2 perplexity
pr=[0.4,0.25,0.5,0.1,0.2]; print('L2 sumlog',sum(math.log(q) for q in pr),'avg',-np.mean(np.log(pr)),'ppl',math.exp(-np.mean(np.log(pr))))
# LONG 2 causal attention scores
S=np.array([[2,1,0],[1,3,1],[0,2,2.]]); M=np.triu(np.full((3,3),-np.inf),1)
def rs(M_): Z=np.exp(M_-M_.max(1,keepdims=True)); return Z/Z.sum(1,keepdims=True)
A=rs(S+M); print('A',A); V=np.array([[1,0],[0,1],[1,1.]]); print('AV',A@V)
# LONG 3 beam k=2, 3 steps
P1={'x':.6,'y':.4}
T={'x':{'x':.55,'y':.45},'y':{'x':.9,'y':.1}}
def beam(k,n):
    B=[((w,),P1[w]) for w in P1]; B=sorted(B,key=lambda b:-b[1])[:k]; hist=[B]
    for _ in range(n-1):
        C=[(s+(w,),p*T[s[-1]][w]) for s,p in B for w in T]; B=sorted(C,key=lambda b:-b[1])[:k]; hist.append(B)
    return hist
for h in beam(2,3): print(h)
import itertools
allp={s:P1[s[0]]*T[s[0]][s[1]]*T[s[1]][s[2]] for s in itertools.product('xy',repeat=3)}
print(sorted(allp.items(),key=lambda kv:-kv[1])[:4]); print('greedy', beam(1,3)[-1])
# LONG 4 HMM estimation
data=[[('the','D'),('old','A'),('man','N')],[('the','D'),('man','N'),('boats','V')],[('old','N'),('man','V'),('boats','N')]]
from collections import Counter
ic=Counter(s[0][1] for s in data); tc=Counter(); ec=Counter(); tg=Counter()
for s in data:
    for w_,t in s: ec[(t,w_)]+=1; tg[t]+=1
    for a,b in zip(s,s[1:]): tc[(a[1],b[1])]+=1
    tc[(s[-1][1],'STOP')]+=1
out=Counter()
for (a,b),v in tc.items(): out[a]+=v
I={k:F(v,3) for k,v in ic.items()}; Tr={k:F(v,out[k[0]]) for k,v in tc.items()}; E={k:F(v,tg[k[0]]) for k,v in ec.items()}
print(I,Tr,E,sep='\n')
def jp(ws,ts):
    p=I.get(ts[0],0)*E.get((ts[0],ws[0]),0)
    for i in range(1,len(ws)): p*=Tr.get((ts[i-1],ts[i]),0)*E.get((ts[i],ws[i]),0)
    return p*Tr.get((ts[-1],'STOP'),0)
tags=['D','A','N','V']
res={ts:jp(['the','old','man','boats'],ts) for ts in itertools.product(tags,repeat=4)}
print({k:v for k,v in res.items() if v>0})
res={ts:jp(['the','old','boats'],ts) for ts in itertools.product(tags,repeat=3)}
print({k:v for k,v in res.items() if v>0})
