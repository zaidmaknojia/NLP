import numpy as np
from fractions import Fraction as F
e=3
C=[(0,0),(0,1),(1,0)]
for v in [(0,0),(1,1),(-1,1)]:
    s=[F(e)**(v[0]*c[0]+v[1]*c[1]) for c in C]; t=sum(s); print(v,[x/t for x in s])
g=np.array([0,0,3.]);b=np.array([0,1,3.]);t=np.array([10,10,10.])
cos=lambda a,c:a@c/np.linalg.norm(a)/np.linalg.norm(c)
print(g@b,g@t,b@t,cos(g,b),cos(g,t),cos(b,t))
print(15000*300+300*100+100+100*2+2, 300*100+100+202, 50*64+64+64*3+3)
def pairs(L,k): return sum(min(k,i)+min(k,L-1-i) for i in range(L))
print(pairs(4,2),pairs(4,1),pairs(2,1)*3)
