import itertools, math
from fractions import Fraction as F
def viterbi(words,tags,init,trans,emit,stop,logspace=True):
    add=(lambda a,b:a+b) if logspace else (lambda a,b:a*b)
    V=[{t:add(init[t],emit[t][words[0]]) for t in tags}]; bp=[{}]
    for w in words[1:]:
        row={};b={}
        for t in tags:
            best=max(tags,key=lambda p:add(V[-1][p],trans[p][t]))
            row[t]=add(add(V[-1][best],trans[best][t]),emit[t][w]); b[t]=best
        V.append(row); bp.append(b)
    fin={t:add(V[-1][t],stop[t]) for t in tags}
    last=max(tags,key=fin.get); path=[last]
    for b in reversed(bp[1:]): path.append(b[path[-1]])
    return V,fin,list(reversed(path))
tags=['N','V']
init={'N':-1,'V':-1}; trans={'N':{'N':-2,'V':-1},'V':{'N':-1,'V':-1}}; stop={'N':-1,'V':-2}
emit={'N':{'they':-1,'can':-3,'fish':-1},'V':{'they':-3,'can':-1,'fish':-1}}
print(viterbi(['they','can','fish'],tags,init,trans,emit,stop))
# fa22 HMM
tags=['J','N']; init={'J':F(2,3),'N':F(1,3)}
trans={'J':{'J':F(1,2),'N':F(1,4)},'N':{'J':F(0),'N':F(1,2)}}; stop={'J':F(1,4),'N':F(1,2)}
emit={'J':{'big':F(1,2),'red':F(1,4),'convertible':F(1,4),'car':F(0)},'N':{'big':F(0),'red':F(0),'convertible':F(1,3),'car':F(2,3)}}
def joint(ws,ts):
    p=init[ts[0]]*emit[ts[0]][ws[0]]
    for i in range(1,len(ws)): p*=trans[ts[i-1]][ts[i]]*emit[ts[i]][ws[i]]
    return p*stop[ts[-1]]
print('Q8',joint(['big','car'],['J','N']))
for s in [['big','convertible','car'],['big','car','convertible'],['red','convertible','car']]:
    ps={ts:joint(s,ts) for ts in itertools.product(tags,repeat=len(s))}
    print(s,{k:v for k,v in ps.items() if v>0})
print(viterbi(['big','convertible','car'],tags,init,trans,emit,stop,logspace=False))
# lecture smoothed HMM they can fish NVV
init={'N':1,'V':0}; trans={'N':{'N':F(1,5),'V':F(3,5)},'V':{'N':F(1,5),'V':F(1,5)}}; stop={'N':F(1,5),'V':F(3,5)}
emit={'N':{'they':1,'can':0,'fish':0},'V':{'they':0,'can':F(1,2),'fish':F(1,2)}}
p=1*1*trans['N']['V']*emit['V']['can']*trans['V']['V']*emit['V']['fish']*stop['V']; print('NVV',p)
# count and normalize from 'they can'/'they fish' N V
print('emission V', F(1,2))
# my estimation example
data=[[('the','D'),('dog','N'),('barks','V')],[('the','D'),('cat','N'),('sleeps','V')],[('a','D'),('dog','N'),('sleeps','V')],[('dogs','N'),('bark','V')]]
from collections import Counter
ic=Counter(s[0][1] for s in data); tc=Counter(); ec=Counter(); tagc=Counter()
for s in data:
    for (w,t) in s: ec[(t,w)]+=1; tagc[t]+=1
    for a,b in zip(s,s[1:]): tc[(a[1],b[1])]+=1
    tc[(s[-1][1],'STOP')]+=1
print('init',{k:F(v,len(data)) for k,v in ic.items()})
outs=Counter(); 
for (a,b),v in tc.items(): outs[a]+=v
print('trans',{k:F(v,outs[k[0]]) for k,v in tc.items()})
print('emit',{k:F(v,tagc[k[0]]) for k,v in ec.items()})
