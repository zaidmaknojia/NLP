from collections import Counter
def greedy(word,vocab):
    out=[];i=0
    while i<len(word):
        for j in range(len(word),i,-1):
            if word[i:j] in vocab: out.append(word[i:j]); i=j; break
        else: out.append(word[i]); i+=1
    return out
V={'A','AA','AAB','ABB','BAAA'}; print(greedy('AABAAA',V))
V2={'good','x','q','not','gre','at','great'}
for w in ['goodx','great','greatq','greqat','not']: print(w,greedy(w,V2))
# min pieces DP
def minseg(word,vocab):
    best=[None]*(len(word)+1); best[0]=[]
    for j in range(1,len(word)+1):
        for i in range(j):
            if best[i] is not None and word[i:j] in vocab:
                c=best[i]+[word[i:j]]
                if best[j] is None or len(c)<len(best[j]): best[j]=c
    return best[-1]
print(minseg('AABAAA',V))
# BPE
corpus={'low':5,'lower':2,'newest':6,'widest':3}
words={tuple(w)+('_',):c for w,c in corpus.items()}
for step in range(8):
    pairs=Counter()
    for w,c in words.items():
        for a,b in zip(w,w[1:]): pairs[(a,b)]+=c
    best=max(pairs.items(),key=lambda kv:(kv[1],));  # first max
    top=[p for p,c in pairs.items() if c==best[1]]
    print(step+1,'pair counts top',sorted(pairs.items(),key=lambda kv:-kv[1])[:4])
    a,b=best[0]
    nw={}
    for w,c in words.items():
        out=[];i=0
        while i<len(w):
            if i<len(w)-1 and w[i]==a and w[i+1]==b: out.append(a+b); i+=2
            else: out.append(w[i]); i+=1
        nw[tuple(out)]=c
    words=nw; print(' merge',a+b,list(words))
