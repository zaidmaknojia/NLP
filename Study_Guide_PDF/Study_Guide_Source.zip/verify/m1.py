import math, numpy as np
np.set_printoptions(precision=5, suppress=True)
def perceptron(data, feats, alpha=1.0, w0=None, rule='gt', epochs=10, verbose=True, stop_on_converge=True):
    w = np.zeros(len(data[0][0])) if w0 is None else np.array(w0,float)
    log=[]
    for ep in range(epochs):
        changed=False
        for x,y in data:
            s = w@np.array(x,float)
            pred = 1 if (s>0 if rule=='gt' else s>=0) else -1
            if pred!=y:
                w = w + alpha*y*np.array(x,float); changed=True
            log.append((ep+1,x,y,s,pred,w.copy()))
        if not changed and stop_on_converge: break
    if verbose:
        for r in log: print(r)
    return w, changed
print("== lecture ex: M G B N")
perceptron([([1,1,0,0],1),([1,0,1,0],-1),([0,1,0,1],-1)],None)
print("== exercise 1.1 Q1 [good,bad,not]")
perceptron([([1,0,0],1),([1,0,1],-1),([0,1,0],-1)],None)
print("== exercise 1.1 Q2 one epoch")
perceptron([([1,0,0],1),([0,1,0],-1),([1,0,1],-1),([0,1,1],1)],None,epochs=1)
print("== exercise Q2 more epochs (should never converge)")
w,ch=perceptron([([1,0,0],1),([0,1,0],-1),([1,0,1],-1),([0,1,1],1)],None,epochs=50,verbose=False); print(w,ch)
print("== fa22 Q3a")
perceptron([([1,0],1),([1,1],1),([0,1],-1)],None,epochs=1)
print("== fa23 Q2b rule >=0, [good,great,not]")
perceptron([([0,0,0],1),([0,1,0],1),([0,1,1],-1),([1,0,1],-1)],None,rule='ge',epochs=1)
print("== fa23 Q2b with lecture rule >0")
perceptron([([0,0,0],1),([0,1,0],1),([0,1,1],-1),([1,0,1],-1)],None,rule='gt',epochs=1)
sig=lambda z:1/(1+math.exp(-z))
print("== LR worked")
f=np.array([1,0,1,1.]); w=np.array([1,-2,0.5,-1]); z=w@f; p=sig(z); print('z',z,'p',p,'loss+',-math.log(p),'grad',-(1-p)*f); w1=w+0.1*(1-p)*f; print('w1',w1)
f2=np.array([0,1,1,1.]); z2=w1@f2; p2=sig(z2); print('z2',z2,'p+',p2,'loss- ',-math.log(1-p2)); w2=w1-0.1*p2*f2; print('w2',w2)
print("== tfidf")
docs=["the movie was great","the movie was bad","the plot was great great","a great cast"]
N=len(docs)
for wd in ["the","great","bad","was","plot"]:
    df=sum(wd in d.split() for d in docs); print(wd,df,math.log10(N/df), math.log(N/df))
print('tfidf great in d3 log10', 2*math.log10(4/3))
print("== w^2 SGD")
for a in [0.1,0.25,0.5,0.75,1.0,1.1]:
    w=-1.0; seq=[w]
    for _ in range(5): w=w-a*2*w; seq.append(round(w,4))
    print(a,seq)
print("== A2 quadratic")
def dist(a,k): return math.sqrt((1-2*a)**(2*k)+(1-16*a)**(2*k))
for a in [0.0625,0.1,0.1066,0.11,0.12,0.125,0.13]:
    ks=[k for k in range(1,200) if dist(a,k)<0.1]; print(a, ks[0] if ks else None, dist(a,10))
from scipy.optimize import minimize_scalar
for k in [9,10]:
    r=minimize_scalar(lambda a:dist(a,k),bounds=(0,0.125),method='bounded'); print(k,r.x,r.fun)
