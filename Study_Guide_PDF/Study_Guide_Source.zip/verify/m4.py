import numpy as np, math
from fractions import Fraction as F
np.set_printoptions(precision=4, suppress=True)
from collections import Counter
def bigram(pairs):
    c=Counter(); ctx=Counter()
    for (a,b),n in pairs.items(): c[(a,b)]+=n; ctx[a]+=n
    return lambda b,a: F(c[(a,b)],ctx[a]) if ctx[a] else None
base={('the','frog'):4,('frog','is'):2,('frog','was'):4,('is','UNK'):1,('is','frog'):1}
def prob(P,ws):
    p=F(1); prev=ws[0]
    for w in ws[1:]: p*=P(w,prev); prev=w
    return p
P=bigram(base); print('Q7',prob(P,['the','frog','is','UNK']))
def add(sent):
    d=dict(base); toks=sent.split()
    toks=[t if t in {'the','frog','is','was'} else 'UNK' for t in toks]
    for a,b in zip(toks,toks[1:]): d[(a,b)]=d.get((a,b),0)+1
    return bigram(d)
for s in ["the frog is black","frog is frog is frog is","the is blue","frog frog frog frog"]:
    print(s, prob(add(s),['the','frog','is','UNK']), float(prob(add(s),['the','frog','is','UNK'])))
print('ppl', math.exp(-np.mean(np.log([1/4,1/3,1/4,1/3]))))
# corpus example for worked n-gram
corpus=["<s> I am Sam </s>","<s> Sam I am </s>","<s> I do not like green eggs and ham </s>"]
c=Counter(); u=Counter()
for s in corpus:
    t=s.split()
    for a,b in zip(t,t[1:]): c[(a,b)]+=1; u[a]+=1
for a,b in [('<s>','I'),('I','am'),('am','Sam'),('Sam','</s>'),('<s>','Sam'),('am','</s>'),('I','do')]:
    print(a,b,F(c[(a,b)],u[a]))
p=F(c[('<s>','I')],u['<s>'])*F(c[('I','am')],u['I'])*F(c[('am','Sam')],u['am'])*F(c[('Sam','</s>')],u['Sam'])
print('P(<s> I am Sam </s>)',p, float(p), 'ppl over 4 predictions', float(p)**(-1/4))
print('discount lambda',3*0.2/4, 1.8/4, 0.8/4)
# attention
E=np.array([[1,0],[1,0],[0,1],[1,0.]])
q=np.array([0,1.]); s=E@q; e=3.0
w=e**s/np.sum(e**s); print('attn e=3',w, w@E, 'avg',E.mean(0))
WQ=np.array([[0,1],[0,1.]]); WK=10*np.eye(2)
Q=E@WQ; K=E@WK; S=Q@K.T; print(S)
A=np.exp(S)/np.exp(S).sum(1,keepdims=True); print(A[0], 1/(math.exp(10)+3))
# numeric self-attn example
X=np.array([[1,0],[0,1],[1,1.]])
WQ=np.array([[1,0],[0,1.]]); WK=np.array([[1,1],[0,1.]]); WV=np.array([[1,0],[0,2.]])
Q=X@WQ;K=X@WK;V=X@WV; S=Q@K.T; Ss=S/np.sqrt(2)
def rs(M): Z=np.exp(M-M.max(1,keepdims=True)); return Z/Z.sum(1,keepdims=True)
print('Q',Q,'K',K,'V',V,'S',S,'S/sqrt2',Ss,sep='\n')
A=rs(S); print('A unscaled',A,'out',A@V,sep='\n')
A2=rs(Ss); print('A scaled',A2,'out',A2@V,sep='\n')
M=np.triu(np.full((3,3),-np.inf),1); A3=rs(S+M); print('causal',A3,'out',A3@V,sep='\n')
