import numpy as np, math
np.set_printoptions(precision=5, suppress=True)
def sm(s): e=np.exp(s-s.max()); return e/e.sum()
print("== lecture MC perceptron (tie -> class 3)")
def mcp(data, C, d, tie_last=True, epochs=1):
    W=np.zeros((C,d))
    for ep in range(epochs):
        for x,y in data:
            x=np.array(x,float); s=W@x
            m=s.max(); cands=[c for c in range(C) if s[c]==m]
            pred=cands[-1] if tie_last else cands[0]
            print(ep+1,x,y+1,s,pred+1,end=' ')
            if pred!=y: W[y]+=x; W[pred]-=x
            print(W.tolist())
    return W
mcp([([1,1,0],0),([1,0,1],1)],3,3)
print("== multiclass LR exercise 2.1")
x=np.array([1,1,0.]); W=np.zeros((3,3)); p=sm(W@x); print(p)
G=np.outer(p,x); G[0]-=x; print("update", -G)
print("== lecture topic example DW scores")
print("== XOR tanh")
V=np.array([[1,0],[0,1],[1,1.]]); w=np.array([-1,-1,1.5])
for x,y in [((0,0),-1),((1,0),1),((0,1),1),((1,1),-1)]:
    z=np.tanh(V@np.array(x,float)); print(x,y,z,w@z)
print("== backprop worked")
f=np.array([1,0,1.]); V=np.array([[0.5,-1,0.2],[0,1,-1.]]); W=np.array([[1,-1],[0.5,2.]]); gold=0
a=V@f; z=np.tanh(a); s=W@z; p=sm(s); L=-math.log(p[gold])
print('a',a,'z',z,'s',s,'p',p,'L',L)
e=np.zeros(2); e[gold]=1
dW=np.outer(p-e,z); dz=W.T@(p-e); da=dz*(1-z**2); dV=np.outer(da,f)
print('dW',dW,'dz',dz,'da',da,'dV',dV,sep='\n')
def loss(V,W): return -math.log(sm(W@np.tanh(V@f))[gold])
eps=1e-6; num=np.zeros_like(V)
for i in range(2):
  for j in range(3):
    Vp=V.copy(); Vp[i,j]+=eps; num[i,j]=(loss(Vp,W)-loss(V,W))/eps
print('numdV',num)
alpha=0.1; print('W new',W-alpha*dW,'V new',V-alpha*dV,sep='\n'); print('L new',loss(V-alpha*dV,W-alpha*dW))
print("== param counts")
for n,d,C in [(10000,100,2),(300,200,2),(50,150,2)]: print(n,d,C,'no bias',d*n+C*d,'bias',d*n+d+C*d+C)
print("== softmax examples")
print(sm(np.array([2.,1,0])), sm(np.array([7.6,-1.9,0])))
