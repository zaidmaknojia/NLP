#!/bin/bash
# usage: build.sh NAME "Title" "Subtitle" t01 t02 ...
name=$1; title=$2; sub=$3; shift 3
f=src/$name.tex
{
echo '\documentclass[11pt,oneside,openany]{book}'
echo '\input{preamble}'
echo "\\hypersetup{pdftitle={$title}}"
echo '\begin{document}'
echo "\\modtitlepage{$title}{$sub}"
echo '\input{frontmatter-short}'
echo '\tableofcontents'
for t in "$@"; do echo "\\input{topics/$t}"; done
echo '\end{document}'
} > $f
cd src && latexmk -pdf -interaction=nonstopmode -halt-on-error -outdir=../build $name.tex > ../build/$name.log.txt 2>&1
status=$?
grep -E "^! |Warning: Reference|undefined|Overfull \\\\hbox \([3-9][0-9]|Overfull \\\\hbox \([0-9]{3}" ../build/$name.log ../build/$name.log.txt 2>/dev/null | sort | uniq | head -40
echo "exit=$status"
